﻿Imports System
Imports System.Data
Imports System.Data.SqlClient

Partial Class SagePointHealthAccountUpdate
    Inherits System.Web.UI.Page


    Public Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        If Not Page.IsPostBack Then
            getData(Me.User.Identity.Name)
        End If
    End Sub

    Private Sub getData(ByVal user As String)
        Dim con As New SqlConnection
        Dim da As New SqlDataAdapter
        Dim dt As New DataTable
        Dim accountinfoSQL As SqlCommand
        Dim sqlComm As String

        Try
            con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
            con.Open()
            sqlComm = "SELECT * FROM  BrainTrust.Customer_Data WHERE SSN = '" & Session("SSN") & "'"
            accountinfoSQL = New SqlCommand(sqlComm, con)

            da = New SqlDataAdapter(accountinfoSQL)
            dt = New DataTable()
            da.Fill(dt)
            If dt.Rows.Count > 0 Then
                BirthDateText1.Text = dt.Rows(0).Table(0)("DOB").ToString()
                SocialSecurityText1.Text = dt.Rows(0).Table(0)("SSN").ToString()
                PasswordText1.Text = dt.Rows(0).Table(0)("Password").ToString()
                FirstNameText1.Text = dt.Rows(0).Table(0)("First_Name").ToString()
                LastNameText1.Text = dt.Rows(0).Table(0)("Last_Name").ToString()
                EmailAddressText1.Text = dt.Rows(0).Table(0)("Email_Address").ToString()
                TelephoneText1.Text = dt.Rows(0).Table(0)("Phone_Number").ToString()
                FaxText1.Text = dt.Rows(0).Table(0)("Fax_Number").ToString()
                StreetAddressText1.Text = dt.Rows(0).Table(0)("Address").ToString()
                CityText1.Text = dt.Rows(0).Table(0)("City").ToString()
                StateListDropdown.SelectedValue = dt.Rows(0).Table(0)("State").ToString()
                PostalCodeText1.Text = dt.Rows(0).Table(0)("Postal_Code").ToString()

            End If
        Catch ex As Exception
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Error while connecting to SQL Server.');", True)
        End Try
        con.Close()
    End Sub

    Public Sub UpdateAccountButton_Click(sender As System.Object, e As System.EventArgs) Handles UpdateAccountButton.Click

        UpdateAdminAccount()

    End Sub

    Private Sub UpdateAdminAccount()
        Dim con As New SqlConnection
        Dim updateSQL As SqlCommand
        Dim sqlComm As String

        con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
        con.Open()
        sqlComm = "UPDATE BrainTrust.Customer_Data SET Password = @Password, First_Name = @First_Name, Last_Name = @Last_Name, SSN = @SSN, Email_Address = @Email_Address, Phone_Number = @Phone_Number, Fax_Number = @Fax_Number, Address = @Address, City = @City, State = @State, Postal_Code = @Postal_Code, DOB = @DOB WHERE SSN = '" & Session("SSN") & "'"

        updateSQL = New SqlCommand(sqlComm, con)

        updateSQL.Parameters.AddWithValue("@Password", SqlDbType.VarChar).Value = PasswordText1.Text
        updateSQL.Parameters.AddWithValue("@First_Name", SqlDbType.VarChar).Value = FirstNameText1.Text
        updateSQL.Parameters.AddWithValue("@Last_Name", SqlDbType.VarChar).Value = LastNameText1.Text
        updateSQL.Parameters.AddWithValue("@SSN", SqlDbType.VarChar).Value = SocialSecurityText1.Text
        updateSQL.Parameters.AddWithValue("@Email_Address", SqlDbType.VarChar).Value = EmailAddressText1.Text
        updateSQL.Parameters.AddWithValue("@Phone_Number", SqlDbType.VarChar).Value = TelephoneText1.Text
        updateSQL.Parameters.AddWithValue("@Fax_Number", SqlDbType.VarChar).Value = TelephoneText1.Text
        updateSQL.Parameters.AddWithValue("@Address", SqlDbType.VarChar).Value = StreetAddressText1.Text
        updateSQL.Parameters.AddWithValue("@City", SqlDbType.VarChar).Value = CityText1.Text
        updateSQL.Parameters.AddWithValue("@State", SqlDbType.VarChar).Value = StateListDropdown.SelectedValue
        updateSQL.Parameters.AddWithValue("@Postal_Code", SqlDbType.VarChar).Value = PostalCodeText1.Text
        updateSQL.Parameters.AddWithValue("@DOB", SqlDbType.VarChar).Value = BirthDateText1.Text

        updateSQL.ExecuteNonQuery()
        con.Close()

    End Sub

End Class
