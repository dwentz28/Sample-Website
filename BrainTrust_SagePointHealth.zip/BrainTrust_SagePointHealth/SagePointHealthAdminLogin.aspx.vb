﻿Imports System
Imports System.Data
Imports System.Data.SqlClient

Partial Class SagePointHealthAdminLogin
    Inherits System.Web.UI.Page
   

    Public Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Dim con As New SqlConnection
       
        Try
            con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
            con.Open()
        Catch ex As Exception
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Error while connecting to SQL Server.');", True)

        End Try
    End Sub

    'Login Button
    Public Sub btnlogin_Click(sender As System.Object, e As System.EventArgs) Handles btnLogin.Click

        ConnectToSQL()

    End Sub

    'Connect to SQL method

    Public Sub ConnectToSQL()

        Dim con As New SqlConnection
        Dim cmd As SqlCommand
        Dim sqlComm As String
  
        Dim Password As String = ""
        Dim Password2 As String = ""
        Dim SSN As String = ""
        Dim Is_Admin As Boolean = False

        Try

            'change the data source and initial catalog according to your sql server engine and data base
            con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
            con.Open()


            'change the data fields names and table according to your database
            sqlComm = "SELECT SSN, Password, Admin_Account FROM  BrainTrust.Customer_Data WHERE SSN = '" & txtUsername.Text & "' AND Password = '" & txtPassword.Text & "'"
            cmd = New SqlCommand(sqlComm, con)
            Dim lrd As SqlDataReader = cmd.ExecuteReader()
            If lrd.HasRows Then
                While lrd.Read()

                    'Do something here
                    Password = lrd("Password").ToString()
                    SSN = lrd("SSN").ToString()
                    Is_Admin = lrd("Admin_Account").ToString()

                    Password2 = txtPassword.Text()

                    If Password = Password2 And SSN = txtUsername.Text And Is_Admin = True Then
                        Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Username and Password match..,Authentication Complete');", True)
                        Session("SSN") = SSN
                        Response.Redirect("SagePointHealthAdminIndex.aspx")
                    Else
                        Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Access not permitted based on username and password submitted..,Authentication Complete');", True)
                        'Clear all fields
                        txtPassword.Text = ""
                        txtUsername.Text = ""
                    End If

                End While

            Else
                Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Username and Password do not match..,Authentication Failure');", True)
                'Clear all fields
                txtPassword.Text = ""
                txtUsername.Text = ""
            End If

        Catch ex As Exception
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Error while connecting to SQL Server.');", True)
        Finally
            con.Close() 'Whether there is error or not. Close the connection.

        End Try

    End Sub

    Public Sub txtUsername_TextChanged(sender As System.Object, e As System.EventArgs) Handles txtUsername.TextChanged

    End Sub

    Public Sub txtPassword_TextChanged(sender As System.Object, e As System.EventArgs) Handles txtPassword.TextChanged

    End Sub

    Public Sub btnClear_Click(sender As System.Object, e As System.EventArgs) Handles btnClear.Click
        'User clicking on cancel button only clears field
        ' and refocus to first field

        txtUsername.Text = ""
        txtPassword.Text = ""
        txtUsername.Focus()
    End Sub

End Class

