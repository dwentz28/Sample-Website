﻿Imports System
Imports System.Data
Imports System.Data.SqlClient

Partial Class BenefitEnrollment_GroupBenefits
    Inherits System.Web.UI.Page

    Public Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        'Establishes current user credentials
        If Not Page.IsPostBack Then
            getData(Me.User.Identity.Name)
            GetBenefitPremiums()
        End If



    End Sub


    Public Sub ConfirmBenefitsButton_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnConfirm.Click
        Try
            Group_Benefits_Enrollment()
            Response.Redirect("BenefitEnrollment_BenefitElections.aspx")
        Catch ex As Exception
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert(Selection Error, Please only choose ONE benefit per enrollment session');", True)
        End Try
    End Sub

    Public Sub Group_Benefits_Enrollment()
        Dim con As New SqlConnection
        Dim GrpBeneiftsEnrollmentSQL As SqlCommand
        Dim sqlComm As String
        Dim startDate As Date = Date.Now.Date
        Dim endDate As Date = Date.Now.Date.AddYears(1)


        con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
        con.Open()
        sqlComm = "INSERT INTO BrainTrust.Benefits_Package (Benefit_ID, Customer_ID, Payment_ID, Start_Date, End_Date, SSN) VALUES (@Benefit_ID, @CustomerID, @Payment_ID, @Start_Date, @End_date, @SSN)"

        GrpBeneiftsEnrollmentSQL = New SqlCommand(sqlComm, con)

        If cbGrpTermLifeIns.Checked Then
            GrpBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Benefit_ID", SqlDbType.VarChar).Value = 1
        ElseIf cbGrpUniLifeIns.Checked Then
            GrpBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Benefit_ID", SqlDbType.VarChar).Value = 5
        ElseIf cbGrpShortTermDisIns.Checked Then
            GrpBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Benefit_ID", SqlDbType.VarChar).Value = 10
        ElseIf cbGrpLongTermDisIns.Checked Then
            GrpBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Benefit_ID", SqlDbType.VarChar).Value = 10
        ElseIf cbGrpDentalIns.Checked Then
            GrpBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Benefit_ID", SqlDbType.VarChar).Value = 8
        ElseIf cbGrpLimitedBenMedPlanIns.Checked Then
            GrpBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Benefit_ID", SqlDbType.VarChar).Value = 11
        ElseIf cbGrpCriticalIllIns.Checked Then
            GrpBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Benefit_ID", SqlDbType.VarChar).Value = 12
        ElseIf cbGrpCancerSpecDisIns.Checked Then
            GrpBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Benefit_ID", SqlDbType.VarChar).Value = 14
        ElseIf cbGrpAccidentIns.Checked Then
            GrpBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Benefit_ID", SqlDbType.VarChar).Value = 13
        ElseIf cbGrpHospIndemIns.Checked Then
            GrpBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Benefit_ID", SqlDbType.VarChar).Value = 15
        ElseIf cbGrpIndemMedIns.Checked Then
            GrpBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Benefit_ID", SqlDbType.VarChar).Value = 16
        ElseIf cbGrpVisionIns.Checked Then
            GrpBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Benefit_ID", SqlDbType.VarChar).Value = 17
        ElseIf cbGrpMajorMedCompIns.Checked Then
            GrpBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Benefit_ID", SqlDbType.VarChar).Value = 18
        End If
        GrpBeneiftsEnrollmentSQL.Parameters.AddWithValue("@CustomerID", SqlDbType.Int).Value = GetCustomerID()
        GrpBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Payment_ID", SqlDbType.VarChar).Value = 2
        GrpBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Start_Date", SqlDbType.VarChar).Value = startDate.ToString("MM/dd/yyyy")
        GrpBeneiftsEnrollmentSQL.Parameters.AddWithValue("@End_date", SqlDbType.VarChar).Value = endDate.ToString("MM/dd/yyyy")
        GrpBeneiftsEnrollmentSQL.Parameters.AddWithValue("@SSN", SqlDbType.VarChar).Value = Session("SSN")

        GrpBeneiftsEnrollmentSQL.ExecuteNonQuery()
        con.Close()


    End Sub

    Private Sub getData(ByVal user As String)
        Dim con As New SqlConnection
        Dim da As New SqlDataAdapter
        Dim dt As New DataTable
        Dim accountinfoSQL As SqlCommand
        Dim sqlComm As String

        Try
            con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
            con.Open()
            sqlComm = "SELECT First_Name,Last_Name FROM  BrainTrust.Customer_Data WHERE SSN = '" & Session("SSN") & "'"
            accountinfoSQL = New SqlCommand(sqlComm, con)

            da = New SqlDataAdapter(accountinfoSQL)
            dt = New DataTable()
            da.Fill(dt)
            If dt.Rows.Count > 0 Then
                lblFirstName.Text = dt.Rows(0).Table(0)("First_Name").ToString()
                lblLastName.Text = dt.Rows(0).Table(0)("Last_Name").ToString()
            ElseIf dt.Rows.Count <= 0 Then
                lblFirstName.Text = "Current User Exist Not Logged In"
            End If
        Catch ex As Exception
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Error while connecting to SQL Server.');", True)
        End Try
        con.Close()



    End Sub

    Function GetCustomerID() As Integer
        Dim CustomerID As Integer
        Dim con As New SqlConnection
        Dim da As New SqlDataAdapter
        Dim dt As New DataTable
        Dim accountinfoSQL As SqlCommand
        Dim sqlComm As String

        Try
            con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
            con.Open()
            sqlComm = "SELECT Customer_ID FROM  BrainTrust.Customer_Data WHERE SSN = '" & Session("SSN") & "'"
            accountinfoSQL = New SqlCommand(sqlComm, con)

            da = New SqlDataAdapter(accountinfoSQL)
            dt = New DataTable()
            da.Fill(dt)
            If dt.Rows.Count > 0 Then
                CustomerID = dt.Rows(0).Table(0)("Customer_ID").ToString()
            End If
        Catch ex As Exception
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Error while connecting to SQL Server.');", True)
        End Try
        con.Close()

        Return CustomerID

    End Function

    Sub GetBenefitPremiums()
        Dim con As New SqlConnection
        Dim da As New SqlDataAdapter
        Dim dt As New DataTable
        Dim accountinfoSQL As SqlCommand
        Dim sqlComm As String

        Try
            con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
            con.Open()
            sqlComm = "SELECT Benefit_Premium FROM BrainTrust.Benefit_Type"
            accountinfoSQL = New SqlCommand(sqlComm, con)

            da = New SqlDataAdapter(accountinfoSQL)
            dt = New DataTable()
            da.Fill(dt)
            If dt.Rows.Count > 0 Then
                lblGrpTermLifeIns.Text = dt.Rows(0).Table(0)("Benefit_Premium").ToString()
                lblGrpUniLifeIns.Text = dt.Rows(0).Table(16)("Benefit_Premium").ToString()
                lblGrpAccidentIns.Text = dt.Rows(0).Table(4)("Benefit_Premium").ToString()
                lblGrpCancerSpecDisIns.Text = dt.Rows(0).Table(5)("Benefit_Premium").ToString()
                lblGrpCriticalIllIns.Text = dt.Rows(0).Table(3)("Benefit_Premium").ToString()
                lblGrpDentalIns.Text = dt.Rows(0).Table(19)("Benefit_Premium").ToString()
                lblGrpHospIndemIns.Text = dt.Rows(0).Table(6)("Benefit_Premium").ToString()
                lblGrpIndemMedIns.Text = dt.Rows(0).Table(7)("Benefit_Premium").ToString()
                lblGrpLimitedBenMedPlanIns.Text = dt.Rows(0).Table(2)("Benefit_Premium").ToString()
                lblGrpLongTermDisIns.Text = dt.Rows(0).Table(20)("Benefit_Premium").ToString()
                lblGrpMajorMedCompIns.Text = dt.Rows(0).Table(9)("Benefit_Premium").ToString()
                lblGrpVisionIns.Text = dt.Rows(0).Table(8)("Benefit_Premium").ToString()
                lblGrpShortTermDisIns.Text = dt.Rows(0).Table(1)("Benefit_Premium").ToString()
                

            End If
        Catch ex As Exception
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Error while connecting to SQL Server.');", True)
        End Try
        con.Close()

    End Sub
End Class
