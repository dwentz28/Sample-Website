﻿Imports System
Imports System.Data
Imports System.Data.SqlClient

Partial Class BenefitEnrollment_IndividualBenefits
    Inherits System.Web.UI.Page


    Public Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        'Establishes current user credentials
        If Not Page.IsPostBack Then
            getData(Me.User.Identity.Name)
        End If
        GetBenefitPremiums()
    End Sub


    Public Sub ConfirmBenefitsButton_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnConfirm.Click

        Try
            Individual_Benefits_Enrollment()
        Catch ex As Exception
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Selection Error, Please only choose ONE benefit per enrollment session');", True)
        End Try
    End Sub

    Public Sub Individual_Benefits_Enrollment()
        Dim con As New SqlConnection
        Dim IndBeneiftsEnrollmentSQL As SqlCommand
        Dim sqlComm As String
        Dim startDate As Date = Date.Now.Date
        Dim endDate As Date = Date.Now.Date.AddYears(1)

        con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
        con.Open()
        sqlComm = "INSERT INTO BrainTrust.Benefits_Package (Benefit_ID, Customer_ID, Payment_ID, Start_Date, End_Date, SSN) VALUES (@Benefit_ID, @CustomerID, @Payment_ID, @Start_Date, @End_date, @SSN)"

        IndBeneiftsEnrollmentSQL = New SqlCommand(sqlComm, con)

        If cbIndCriticalIllIns.Checked Then
            IndBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Benefit_ID", SqlDbType.VarChar).Value = 19
        ElseIf cbIndUniLifeIns.Checked Then
            IndBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Benefit_ID", SqlDbType.VarChar).Value = 20
        ElseIf cbIndTermLifeIns.Checked Then
            IndBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Benefit_ID", SqlDbType.VarChar).Value = 2
        ElseIf cbIndAccidentIns.Checked Then
            IndBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Benefit_ID", SqlDbType.VarChar).Value = 6
        ElseIf cbIndCancerSpecDiseaseIns.Checked Then
            IndBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Benefit_ID", SqlDbType.VarChar).Value = 7
        ElseIf cbIndDisabilityIncIns.Checked Then
            IndBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Benefit_ID", SqlDbType.VarChar).Value = 21
        ElseIf cbIndHeartStrokeIns.Checked Then
            IndBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Benefit_ID", SqlDbType.VarChar).Value = 3
        ElseIf cbIndHospitalIndemIns.Checked Then
            IndBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Benefit_ID", SqlDbType.VarChar).Value = 4
        End If
        IndBeneiftsEnrollmentSQL.Parameters.AddWithValue("@CustomerID", SqlDbType.Int).Value = GetCustomerID()
        IndBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Payment_ID", SqlDbType.VarChar).Value = 3
        IndBeneiftsEnrollmentSQL.Parameters.AddWithValue("@Start_Date", SqlDbType.VarChar).Value = startDate.ToString("MM/dd/yyyy")
        IndBeneiftsEnrollmentSQL.Parameters.AddWithValue("@End_date", SqlDbType.VarChar).Value = endDate.ToString("MM/dd/yyyy")
        IndBeneiftsEnrollmentSQL.Parameters.AddWithValue("@SSN", SqlDbType.VarChar).Value = Session("SSN")

        IndBeneiftsEnrollmentSQL.ExecuteNonQuery()
        con.Close()
        Response.Redirect("BenefitEnrollment_BenefitElections.aspx")
    End Sub

    Private Sub getData(ByVal user As String)
        Dim con As New SqlConnection
        Dim da As New SqlDataAdapter
        Dim dt As New DataTable
        Dim accountinfoSQL As SqlCommand
        Dim sqlComm As String

        Try
            con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
            con.Open()
            sqlComm = "SELECT First_Name,Last_Name FROM  BrainTrust.Customer_Data WHERE SSN = '" & Session("SSN") & "'"
            accountinfoSQL = New SqlCommand(sqlComm, con)

            da = New SqlDataAdapter(accountinfoSQL)
            dt = New DataTable()
            da.Fill(dt)
            If dt.Rows.Count > 0 Then
                lblFirstName.Text = dt.Rows(0).Table(0)("First_Name").ToString()
                lblLastName.Text = dt.Rows(0).Table(0)("Last_Name").ToString()
            ElseIf dt.Rows.Count <= 0 Then
                lblFirstName.Text = "Current User Exist Not Logged In"
            End If
        Catch ex As Exception
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Error while connecting to SQL Server.');", True)
        End Try
        con.Close()
    End Sub

    Function GetCustomerID() As Integer
        Dim CustomerID As Integer
        Dim con As New SqlConnection
        Dim da As New SqlDataAdapter
        Dim dt As New DataTable
        Dim accountinfoSQL As SqlCommand
        Dim sqlComm As String

        Try
            con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
            con.Open()
            sqlComm = "SELECT Customer_ID FROM  BrainTrust.Customer_Data WHERE SSN = '" & Session("SSN") & "'"
            accountinfoSQL = New SqlCommand(sqlComm, con)

            da = New SqlDataAdapter(accountinfoSQL)
            dt = New DataTable()
            da.Fill(dt)
            If dt.Rows.Count > 0 Then
                CustomerID = dt.Rows(0).Table(0)("Customer_ID").ToString()
            End If
        Catch ex As Exception
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Error while connecting to SQL Server.');", True)
        End Try
        con.Close()

        Return CustomerID

    End Function

    Sub GetBenefitPremiums()
        Dim con As New SqlConnection
        Dim da As New SqlDataAdapter
        Dim dt As New DataTable
        Dim accountinfoSQL As SqlCommand
        Dim sqlComm As String

        Try
            con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
            con.Open()
            sqlComm = "SELECT Benefit_Premium FROM BrainTrust.Benefit_Type"
            accountinfoSQL = New SqlCommand(sqlComm, con)

            da = New SqlDataAdapter(accountinfoSQL)
            dt = New DataTable()
            da.Fill(dt)
            If dt.Rows.Count > 0 Then
                lblIndTermLifeIns.Text = dt.Rows(0).Table(11)("Benefit_Premium").ToString()
                lblIndUniLifeIns.Text = dt.Rows(0).Table(12)("Benefit_Premium").ToString()
                lblIndCriticalIllIns.Text = dt.Rows(0).Table(10)("Benefit_Premium").ToString()
                lblIndCancerSpecDiseaseIns.Text = dt.Rows(0).Table(18)("Benefit_Premium").ToString()
                lblIndDisabilityIncIns.Text = dt.Rows(0).Table(13)("Benefit_Premium").ToString()
                lblIndHeartStrokeIns.Text = dt.Rows(0).Table(14)("Benefit_Premium").ToString()
                lblndHospitalIndemIns.Text = dt.Rows(0).Table(15)("Benefit_Premium").ToString()
                lblIndAccidentIns.Text = dt.Rows(0).Table(17)("Benefit_Premium").ToString()
            End If
        Catch ex As Exception
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Error while connecting to SQL Server.');", True)
        End Try
        con.Close()

    End Sub

End Class
