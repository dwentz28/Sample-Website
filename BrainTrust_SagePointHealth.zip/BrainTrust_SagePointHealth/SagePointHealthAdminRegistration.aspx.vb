﻿Imports System
Imports System.Data
Imports System.Data.SqlClient

Partial Class SagePointHealthAdminRegistration
    Inherits System.Web.UI.Page

    Public Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Dim con As New SqlConnection

        Try
            con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
            con.Open()
        Catch ex As Exception
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Error while connecting to SQL Server.');", True)

        End Try
    End Sub

    Public Sub CreateAccountButton_Click(ByVal sender As Object, ByVal e As EventArgs) Handles CreateAccountButton.Click

        Try
            Register_Admin_Account()
            Response.Redirect("SagePointHealthAdminLogin.aspx")
        Catch ex As Exception
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Error while connecting to SQL Server.');", True)
        End Try

    End Sub

    Public Sub Register_Admin_Account()

        Dim con As New SqlConnection
        Dim registerSQL As SqlCommand
        Dim sqlComm As String

        con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
        con.Open()
        sqlComm = "INSERT INTO BrainTrust.Customer_Data(Password, First_Name, Last_Name, SSN, Email_Address, Phone_Number, Fax_Number, Address, City, State, Postal_Code,DOB,Admin_Account) VALUES (@Password, @First_Name, @Last_Name, @SSN, @Email_Address, @Phone_Number, @Fax_Number, @Address, @City, @State, @Postal_Code, @DOB, @Admin_Account)"

        registerSQL = New SqlCommand(sqlComm, con)

        registerSQL.Parameters.AddWithValue("@Password", SqlDbType.VarChar).Value = PasswordText1.Text
        registerSQL.Parameters.AddWithValue("@First_Name", SqlDbType.VarChar).Value = FirstNameText1.Text
        registerSQL.Parameters.AddWithValue("@Last_Name", SqlDbType.VarChar).Value = LastNameText1.Text
        registerSQL.Parameters.AddWithValue("@SSN", SqlDbType.VarChar).Value = SocialSecurityText1.Text
        registerSQL.Parameters.AddWithValue("@Email_Address", SqlDbType.VarChar).Value = EmailAddressText1.Text
        registerSQL.Parameters.AddWithValue("@Phone_Number", SqlDbType.VarChar).Value = TelephoneText1.Text
        registerSQL.Parameters.AddWithValue("@Fax_Number", SqlDbType.VarChar).Value = TelephoneText1.Text
        registerSQL.Parameters.AddWithValue("@Address", SqlDbType.VarChar).Value = StreetAddressText1.Text
        registerSQL.Parameters.AddWithValue("@City", SqlDbType.VarChar).Value = CityText1.Text
        registerSQL.Parameters.AddWithValue("@State", SqlDbType.VarChar).Value = StateListDropdown.SelectedValue
        registerSQL.Parameters.AddWithValue("@Postal_Code", SqlDbType.VarChar).Value = PostalCodeText1.Text
        registerSQL.Parameters.AddWithValue("@DOB", SqlDbType.VarChar).Value = BirthDateText1.Text
        registerSQL.Parameters.AddWithValue("@Admin_Account", SqlDbType.VarChar).Value = 1


        registerSQL.ExecuteNonQuery()
        con.Close()

    End Sub
End Class
