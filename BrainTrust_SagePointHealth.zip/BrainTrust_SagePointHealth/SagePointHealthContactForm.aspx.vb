﻿
Imports System
Imports System.Data
Imports System.Data.SqlClient


Partial Class SagePointHealthContactForm
    Inherits System.Web.UI.Page


    Public Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        If Not Page.IsPostBack Then
            getData(Me.User.Identity.Name)
        End If
    End Sub

    Private Sub getData(ByVal user As String)
        Dim con As New SqlConnection
        Dim da As New SqlDataAdapter
        Dim dt As New DataTable
        Dim accountinfoSQL As SqlCommand
        Dim sqlComm As String

        Try
            con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
            con.Open()
            sqlComm = "SELECT * FROM  BrainTrust.Customer_Data WHERE SSN = '" & Session("SSN") & "'"
            accountinfoSQL = New SqlCommand(sqlComm, con)

            da = New SqlDataAdapter(accountinfoSQL)
            dt = New DataTable()
            da.Fill(dt)
            If dt.Rows.Count > 0 Then
                FirstNameText1.Text = dt.Rows(0).Table(0)("First_Name").ToString()
                LastNameText1.Text = dt.Rows(0).Table(0)("Last_Name").ToString()
                EmailAddressText1.Text = dt.Rows(0).Table(0)("Email_Address").ToString()
                TelephoneText1.Text = dt.Rows(0).Table(0)("Phone_Number").ToString()
                StreetAddressText1.Text = dt.Rows(0).Table(0)("Address").ToString()
                CityText1.Text = dt.Rows(0).Table(0)("City").ToString()
                StateListDropdown.SelectedValue = dt.Rows(0).Table(0)("State").ToString()
                PostalCodeText1.Text = dt.Rows(0).Table(0)("Postal_Code").ToString()
                lblMember.Text = "Member Inquiry"
            Else
                lblMember.Text = "Non-Member Inquiry"
            End If
        Catch ex As Exception
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Error while connecting to SQL Server.');", True)
        End Try
        con.Close()
    End Sub

    Public Sub SubmitButton_Click(sender As System.Object, e As System.EventArgs) Handles SubmitButton.Click

        FirstNameText1.Text = ""
        LastNameText1.Text = ""
        EmailAddressText1.Text = ""
        TelephoneText1.Text = ""
        StreetAddressText1.Text = ""
        CityText1.Text = ""
        StateListDropdown.SelectedValue = ""
        PostalCodeText1.Text = ""
        CommentsText1.Text = "Thank you for contacting Sage Point Health's Customer Service. We will reply to your inquiry soon."

    End Sub
End Class
