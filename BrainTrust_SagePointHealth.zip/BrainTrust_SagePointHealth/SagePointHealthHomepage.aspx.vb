﻿
Partial Class SagePointHealthHomepage
    Inherits System.Web.UI.Page

End Class
