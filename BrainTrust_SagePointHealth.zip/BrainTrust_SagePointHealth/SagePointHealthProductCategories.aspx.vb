﻿
Partial Class SagePointHealthProductCategories
    Inherits System.Web.UI.Page

End Class
