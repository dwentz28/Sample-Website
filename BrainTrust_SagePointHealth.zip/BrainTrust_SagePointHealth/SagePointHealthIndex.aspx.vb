﻿Imports System
Imports System.Data
Imports System.Data.SqlClient

Partial Class SagePointHealthIndex
    Inherits System.Web.UI.Page


    Public Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        'Establishes current user credentials
        If Not Page.IsPostBack Then
            getData(Me.User.Identity.Name)
        End If
    End Sub

    Protected Sub LogoutButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LogoutButton.Click
        ' Sign out
        FormsAuthentication.SignOut()
        ' Now need to redirect user to login page 
        ' or to the same URL
        Response.Redirect("SagePointHealthLogin.aspx")
    End Sub

    'Gets Enrollment data from current user and displays it on the account homepage
    Private Sub getData(ByVal user As String)
        Dim con As New SqlConnection
        Dim da As New SqlDataAdapter
        Dim dt As New DataTable
        Dim accountinfoSQL As SqlCommand
        Dim sqlComm As String

        Try
            con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
            con.Open()
            sqlComm = "SELECT Description,Benefit_Premium,Start_Date,End_Date FROM BrainTrust.Benefits_Package INNER JOIN BrainTrust.Benefit_Type ON BrainTrust.Benefits_Package.Benefit_ID=BrainTrust.Benefit_Type.Benefit_ID WHERE SSN = '" & Session("SSN") & "'ORDER BY Package_ID DESC"
            accountinfoSQL = New SqlCommand(sqlComm, con)

            da = New SqlDataAdapter(accountinfoSQL)
            dt = New DataTable()
            da.Fill(dt)
            If dt.Rows.Count > 0 Then
                lblBenefitDescription.Text = dt.Rows(0).Table(0)("Description").ToString()
                lblBenefit_Premium.Text = dt.Rows(0).Table(0)("Benefit_Premium").ToString()
                lblBenefit_Start_Date.Text = dt.Rows(0).Table(0)("Start_Date").ToString()
                lblBenefit_End_Date.Text = dt.Rows(0).Table(0)("End_Date").ToString()
            ElseIf dt.Rows.Count <= 0 Then
                lblBenefitDescription.Text = "No Current Benefits Exist"
            End If
        Catch ex As Exception
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Error while connecting to SQL Server.');", True)
        End Try
        con.Close()
    End Sub

    Public Sub SearchBenefitsPackageButton_Click(ByVal sender As Object, ByVal e As EventArgs) Handles SearchBenefitsPackageButton.Click

        Try
            SearchBenefitsPackagesSQL()
        Catch ex As Exception
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Error while connecting to SQL Server.');", True)
        End Try

    End Sub

    Public Sub SearchBenefitsPackagesSQL()
        Dim con As New SqlConnection
        Dim da As New SqlDataAdapter
        Dim dt As New DataTable
        Dim accountinfoSQL As SqlCommand
        Dim sqlComm As String

        Try
            con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
            con.Open()
            sqlComm = "SELECT Description,Benefit_Premium,Start_Date,End_Date FROM BrainTrust.Benefits_Package INNER JOIN BrainTrust.Benefit_Type ON BrainTrust.Benefits_Package.Benefit_ID=BrainTrust.Benefit_Type.Benefit_ID WHERE Package_ID = '" & PackageIDSearchText1.Text & "' AND SSN = '" & Session("SSN") & "'"
            accountinfoSQL = New SqlCommand(sqlComm, con)

            da = New SqlDataAdapter(accountinfoSQL)
            dt = New DataTable()
            da.Fill(dt)
            If dt.Rows.Count > 0 Then
                lblSearch_Benefit_Description.Text = dt.Rows(0).Table(0)("Description").ToString()
                lblSearch_Benefit_Premium.Text = dt.Rows(0).Table(0)("Benefit_Premium").ToString()
                lblSearch_Benefit_Start_Date.Text = dt.Rows(0).Table(0)("Start_Date").ToString()
                lblSearch_Benefit_End_Date.Text = dt.Rows(0).Table(0)("End_Date").ToString()
            ElseIf dt.Rows.Count <= 0 Then
                PackageIDSearchText1.Text = "Benefits Package Does Not Exist"
                lblSearch_Benefit_Description.Text = ""
                lblSearch_Benefit_Premium.Text = ""
                lblSearch_Benefit_Start_Date.Text = ""
                lblSearch_Benefit_End_Date.Text = ""
            End If
        Catch ex As Exception
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Package ID Does Not Match SSN...Try Again');", True)
        End Try
        con.Close()

    End Sub

End Class
