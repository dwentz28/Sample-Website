﻿Imports System
Imports System.IO
Imports System.Data
Imports System.Data.SqlClient

Partial Class SagePointHealthAccountAdminUpload
    Inherits System.Web.UI.Page

    Public Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        'Establishes current user credentials
        If Not Page.IsPostBack Then
            getData(Me.User.Identity.Name)
        End If

    End Sub

    Private Sub getData(ByVal user As String)
        Dim con As New SqlConnection
        Dim da As New SqlDataAdapter
        Dim dt As New DataTable
        Dim accountinfoSQL As SqlCommand
        Dim sqlComm As String

        Try
            con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
            con.Open()
            sqlComm = "SELECT First_Name,Last_Name FROM  BrainTrust.Customer_Data WHERE SSN = '" & Session("SSN") & "'"
            accountinfoSQL = New SqlCommand(sqlComm, con)

            da = New SqlDataAdapter(accountinfoSQL)
            dt = New DataTable()
            da.Fill(dt)
            If dt.Rows.Count > 0 Then
                lblFirstName.Text = dt.Rows(0).Table(0)("First_Name").ToString()
                lblLastName.Text = dt.Rows(0).Table(0)("Last_Name").ToString()
            ElseIf dt.Rows.Count <= 0 Then
                lblFirstName.Text = "Admin Not Logged In"
            End If
        Catch ex As Exception
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Error while connecting to SQL Server.');", True)
        End Try
        con.Close()
    End Sub

    Protected Sub Group_Benefit_Upload(sender As Object, e As EventArgs)
        Dim con As New SqlConnection

        'Upload and save the file
        Dim csvPath As String = Server.MapPath("~/Files/") + Path.GetFileName(FileUpload1.PostedFile.FileName)
        FileUpload1.SaveAs(csvPath)
        Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('File has been saved');", True)

        Dim dt As New DataTable()
        dt.Columns.AddRange(New DataColumn(6) {New DataColumn("Package_ID", GetType(Integer)), New DataColumn("Customer_ID", GetType(Integer)), New DataColumn("Benefit_ID", GetType(String)), New DataColumn("Payment_ID", GetType(String)), New DataColumn("Start_Date", GetType(String)), New DataColumn("End_Date", GetType(String)), New DataColumn("SSN", GetType(String))})

        Dim csvData As String = File.ReadAllText(csvPath)
        For Each row As String In csvData.Split(ControlChars.Lf)
            If Not String.IsNullOrEmpty(row) Then
                dt.Rows.Add()
                Dim i As Integer = 0
                For Each cell As String In row.Split(","c)
                    dt.Rows(dt.Rows.Count - 1)(i) = cell
                    i += 1
                Next
            End If
        Next

        con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
        Using sqlBulkCopy As New SqlBulkCopy(con)
            'Set the database table name
            sqlBulkCopy.DestinationTableName = "BrainTrust.Benefits_Package"
            con.Open()
            sqlBulkCopy.WriteToServer(dt)
            con.Close()
        End Using
    End Sub

    Protected Sub Group_Account_Creation_Upload(sender As Object, e As EventArgs)
        Dim con As New SqlConnection

        'Upload and save the file
        Dim csvPath As String = Server.MapPath("~/Files/") + Path.GetFileName(FileUpload1.PostedFile.FileName)
        FileUpload1.SaveAs(csvPath)
        Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('File has been saved');", True)

        Dim dt As New DataTable()
        dt.Columns.AddRange(New DataColumn(13) {New DataColumn("Customer_ID", GetType(Integer)), New DataColumn("Password", GetType(String)), New DataColumn("First_Name", GetType(String)), New DataColumn("Last_Name", GetType(String)), New DataColumn("DOB", GetType(String)), New DataColumn("Address", GetType(String)), New DataColumn("City", GetType(String)), New DataColumn("State", GetType(String)), New DataColumn("Postal_Code", GetType(String)), New DataColumn("Phone_Number", GetType(String)), New DataColumn("Email_Address", GetType(String)), New DataColumn("SSN", GetType(String)), New DataColumn("Admin_Account", GetType(String)), New DataColumn("Fax_Number", GetType(String))})

        Dim csvData As String = File.ReadAllText(csvPath)
        For Each row As String In csvData.Split(ControlChars.Lf)
            If Not String.IsNullOrEmpty(row) Then
                dt.Rows.Add()
                Dim i As Integer = 0
                For Each cell As String In row.Split(","c)
                    dt.Rows(dt.Rows.Count - 1)(i) = cell
                    i += 1
                Next
            End If
        Next

        con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
        Using sqlBulkCopy As New SqlBulkCopy(con)
            'Set the database table name
            sqlBulkCopy.DestinationTableName = "BrainTrust.Customer_Data"
            con.Open()
            sqlBulkCopy.WriteToServer(dt)
            con.Close()
        End Using
    End Sub

End Class




