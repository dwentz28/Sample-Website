﻿
Imports System
Imports System.Data
Imports System.Data.SqlClient

Partial Class BenefitEnrollment_BenefitElections
    Inherits System.Web.UI.Page

    Public Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        'Establishes current user credentials
        If Not Page.IsPostBack Then
            getData(Me.User.Identity.Name)
        End If
    End Sub

    'Gets Enrollment data from current user and displays it on the account homepage
    Private Sub getData(ByVal user As String)
        Dim con As New SqlConnection
        Dim da As New SqlDataAdapter
        Dim dt As New DataTable
        Dim accountinfoSQL As SqlCommand
        Dim sqlComm As String

        Try
            con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
            con.Open()
            sqlComm = "SELECT Package_ID, Description,Benefit_Premium, Start_Date, End_Date, First_Name, Last_Name FROM BrainTrust.Benefits_Package INNER JOIN BrainTrust.Benefit_Type ON BrainTrust.Benefits_Package.Benefit_ID=BrainTrust.Benefit_Type.Benefit_ID INNER JOIN BrainTrust.Customer_Data ON BrainTrust.Benefits_Package.SSN=BrainTrust.Customer_Data.SSN WHERE BrainTrust.Customer_Data.SSN = '" & Session("SSN") & "' ORDER BY Package_ID DESC"
            accountinfoSQL = New SqlCommand(sqlComm, con)

            da = New SqlDataAdapter(accountinfoSQL)
            dt = New DataTable()
            da.Fill(dt)
            If dt.Rows.Count > 0 Then
                lblFirstName.Text = dt.Rows(0).Table(0)("First_Name").ToString()
                lblLastName.Text = dt.Rows(0).Table(0)("Last_Name").ToString()
                lblBenefit_Description.Text = dt.Rows(0).Table(0)("Description").ToString()
                lblBenefit_Premium.Text = dt.Rows(0).Table(0)("Benefit_Premium").ToString()
                lblPackage_ID.Text = dt.Rows(0).Table(0)("Package_ID").ToString()
                lblBenefitStart_Date.Text = dt.Rows(0).Table(0)("Start_Date").ToString()
                lblBenefitEnd_Date.Text = dt.Rows(0).Table(0)("End_Date").ToString()
            ElseIf dt.Rows.Count <= 0 Then
                lblBenefit_Description.Text = "No Current Benefits Exist"
                lblBenefit_Premium.Text = "No Current Benefits Exist"
            End If
        Catch ex As Exception
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Error while connecting to SQL Server.');", True)
        End Try
        con.Close()
    End Sub

    Public Sub ContinueButton_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnContinue.Click

        Try
            ConfirmAdminAccount()
        Catch ex As Exception
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Error while connecting to SQL Server.');", True)
        End Try

    End Sub

    Private Sub ConfirmAdminAccount()
        Dim con As New SqlConnection
        Dim cmd As SqlCommand
        Dim sqlComm As String
        Dim Is_Admin As Boolean = False

        Try
            'change the data source and initial catalog according to your sql server engine and data base
            con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
            con.Open()

            'change the data fields names and table according to your database
            sqlComm = "SELECT Admin_Account FROM  BrainTrust.Customer_Data WHERE SSN = '" & Session("SSN") & "'"
            cmd = New SqlCommand(sqlComm, con)
            Dim lrd As SqlDataReader = cmd.ExecuteReader()
            If lrd.HasRows Then
                While lrd.Read()

                    'Do something here
                    Is_Admin = lrd("Admin_Account").ToString()

                    If Is_Admin = True Then
                        Response.Redirect("SagePointHealthAdminIndex.aspx")
                    Else
                        Response.Redirect("SagePointHealthIndex.aspx")
                    End If

                End While
            End If

        Catch ex As Exception
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Error while connecting to SQL Server.');", True)
        Finally
            con.Close() 'Whether there is error or not. Close the connection.
        End Try

    End Sub
End Class
