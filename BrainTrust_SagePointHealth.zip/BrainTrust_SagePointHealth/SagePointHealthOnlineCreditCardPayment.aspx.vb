﻿Imports System
Imports System.Data
Imports System.Data.SqlClient

Partial Class SagePointHealthOnlineCreditCardPayment
    Inherits System.Web.UI.Page

    Public Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        'Establishes current user credentials
        If Not Page.IsPostBack Then
            getData(Me.User.Identity.Name)
        End If
    End Sub

    Private Sub getData(ByVal user As String)
        Dim con As New SqlConnection
        Dim da As New SqlDataAdapter
        Dim dt As New DataTable
        Dim accountinfoSQL As SqlCommand
        Dim sqlComm As String

        Try
            con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
            con.Open()
            sqlComm = "SELECT First_Name, Last_Name, Address, City, State, Postal_Code FROM  BrainTrust.Customer_Data WHERE SSN = '" & Session("SSN") & "'"
            accountinfoSQL = New SqlCommand(sqlComm, con)

            da = New SqlDataAdapter(accountinfoSQL)
            dt = New DataTable()
            da.Fill(dt)
            If dt.Rows.Count > 0 Then
                lblFirstName.Text = dt.Rows(0).Table(0)("First_Name").ToString()
                lblLastName.Text = dt.Rows(0).Table(0)("Last_Name").ToString()
                StreetAddressText1.Text = dt.Rows(0).Table(0)("Address").ToString()
                CityText1.Text = dt.Rows(0).Table(0)("City").ToString()
                StateListDropdown.SelectedValue = dt.Rows(0).Table(0)("State").ToString()
                PostalCodeText1.Text = dt.Rows(0).Table(0)("Postal_Code").ToString()
            ElseIf dt.Rows.Count <= 0 Then
                lblFirstName.Text = "Current User Exist Not Logged In"
            End If
        Catch ex As Exception
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Error while connecting to SQL Server.');", True)
        End Try
        con.Close()
    End Sub

    Public Sub ProcessPaymentButton_Click(sender As System.Object, e As System.EventArgs) Handles PaymentButton.Click

        Try
        ProcessPaymentOnAccount()
        Catch ex As Exception
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Error while connecting to SQL Server.');", True)
        End Try

    End Sub

    Private Sub ProcessPaymentOnAccount()
        Dim con As New SqlConnection
        Dim updateSQL As SqlCommand
        Dim sqlComm As String

        con.ConnectionString = "Data Source=lyra2.unfcsd.unf.edu; Initial Catalog=BrainTrust; User ID=BrainTrust; Password=sdh8qvdqdK3yMrc"
        con.Open()
        sqlComm = "UPDATE BrainTrust.Benefits_Package SET Payment_ID = @Payment_ID WHERE SSN = '" & Session("SSN") & "'"

        updateSQL = New SqlCommand(sqlComm, con)

        updateSQL.Parameters.AddWithValue("@Payment_ID", SqlDbType.VarChar).Value = 1
        Page.ClientScript.RegisterStartupScript(Me.GetType(), "Window", "alert('Error while connecting to SQL Server.');", True)

        updateSQL.ExecuteNonQuery()
        con.Close()
        Response.Redirect("SagePointHealthIndex.aspx")

    End Sub


End Class
